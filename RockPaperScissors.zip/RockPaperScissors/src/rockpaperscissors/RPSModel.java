/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rockpaperscissors;

import java.util.Random;

/**
 *
 * @author dcoll
 */
public class RPSModel {
private String playerName;
private String playerCharacter;
private int playerScore;
private String computerCharacter;
private int computerScore;
private final String[] playableCharacters;


public RPSModel(){

        this.playerName = null;
        this.playerCharacter = null;
        this.computerCharacter = null;
        this.playerScore = 0;
        this.computerScore = 0;
        this.playableCharacters = new String[3];
        playableCharacters[0]="Rock";
        playableCharacters[1]="Paper";
        playableCharacters[2]="Scissors";
}

public void setPlayerName(String playerName){
        this.playerName = playerName;
    }
    public String getPlayerName(){
        return playerName;
    }
    
    public void setPlayerCharacter(String playerCharacter){
        this.playerCharacter = playerCharacter;
    }
    public String getPlayerCharacter(){
        return playerCharacter;
    }
   
    public void setComputerCharacter(){
        Random randomCharacterGenerator = new Random();
       this.computerCharacter = playableCharacters[randomCharacterGenerator.nextInt(playableCharacters.length)];
        
    }
    public String getComputerCharacter(){
        return computerCharacter;
    }
    
    public void setPlayerScore(){
        this.playerScore++;
    }
    public int getPlayerScore(){
        return playerScore;
    }
    
    public void setComputerScore(){
        this.computerScore++;
    }
    public int getComputerScore(){
        return computerScore;
    }
  public void resetPlayerScore(){
        this.playerScore = 0;
    }
    public void resetComputerScore(){
        this.computerScore = 0;
    }
 public String getChampion(){
        String TIE = "No one";
        String CPU = "CPU";
        int playerFinalScore  = getPlayerScore();
        int computerFinalScore = getComputerScore();
        if(playerFinalScore>computerFinalScore){
           return getPlayerName();
        }else if(computerFinalScore>playerFinalScore){
            return CPU;
        }else{
            return TIE;
        }
  
 }
 public String[] getPlayableCharacters(){
     return playableCharacters;
 }

}
