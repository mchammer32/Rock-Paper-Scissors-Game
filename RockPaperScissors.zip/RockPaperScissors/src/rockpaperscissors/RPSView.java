/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rockpaperscissors;

import javax.swing.JFrame;

/**
 *
 * @author dcoll
 */
public class RPSView {
    public static void main(String[]args){
      
      
    java.awt.EventQueue.invokeLater(() -> {
        RPSController controller = new RPSController();
        controller.setResizable(false);
        controller.setLocationRelativeTo(null);
        controller.setVisible(true);
        controller.setSize(863,363);
        controller.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    });
    }
        
         
    }
    
    

